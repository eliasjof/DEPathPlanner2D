from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.offsetbox import TextArea, DrawingArea, OffsetImage, AnnotationBbox
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,                AutoMinorLocator)

#from brokenaxes import brokenaxes
from matplotlib.gridspec import GridSpec

from geomdl import BSpline
from geomdl import utilities
from geomdl import exchange
from geomdl import operations
from geomdl.visualization import VisMPL
from geomdl import knotvector
import numpy as np
from geomdl import NURBS

import de2Dplanners

def spline(dt, p0, p1, p0l, p1l):
        """ retorna um conjunto de pontos que compõem um spline, componente x: fx e componente y: fy
        """  
        t = np.arange(0,1,dt)  
        f1 = 2*t**3 -3*t**2 + 1
        f2 = -2*t**3 + 3*t**2
        f3 = t**3 -2*t**2 + t
        f4 = t**3 - t**2    

        fx = p0[0]*f1 + p1[0]*f2 + p0l[0]*f3 + p1l[0]*f4
        fy = p0[1]*f1 + p1[1]*f2 + p0l[1]*f3 + p1l[1]*f4

        return fx, fy

def nurbs(pti, ptf, thi, thf, points, weigths = [1.0,1.0,1.0,1.0,1.0], alpha1=0.4, alpha2=0.4, angle_format='d', delta=0.01):
    
    if angle_format=='d':
        thi = thi*np.pi/180.0
        thf = thf*np.pi/180.0
    
    
    curve = NURBS.Curve()
    # Set degree
    curve.degree = 5
    # para determinar o segundo e o penultimo ponto de controle a partir do angulo desejado
    distT = np.linalg.norm(np.array(ptf) - np.array(pti))
    vi = alpha1*distT #porcentagem do comprimento total da distância entre os dois pontos
    vf = alpha2*distT
    pti2 = [np.cos(thi)*vi + pti[0], np.sin(thi)*vi + pti[1]]
    ptf2 = [-np.cos(thf)*vf + ptf[0], - np.sin(thf)*vf + ptf[1]]

    # Set control points
    ctrlpts = []
    ctrlpts.append(pti)
    ctrlpts.append(pti2)
    for pt in points:
        ctrlpts.append(pt)
    ctrlpts.append(ptf2)
    ctrlpts.append(ptf)
    curve.ctrlpts = ctrlpts
    
    curve.knotvector = knotvector.generate(curve.degree, len(ctrlpts))
    # Set evaluation delta
    curve.delta = delta
    curve.weights = weigths
    # Evaluate curve
    curve.evaluate()        

    f = np.array(curve.evalpts)
    fx = [fi[0] for fi in f]
    fy = [fi[1] for fi in f]
    return curve, fx, fy

def drawCurves(X, ax,problem_params, l='-',c='', angle=0, alphac=1.0,label="", legend="", robot_in_path=False):
    

    r = problem_params["r"]
    obs = problem_params["obs"]
    pinit = problem_params["pinit"]
    pgoal = problem_params["pgoal"]
    vinit = problem_params["vinit"]
    vgoal = problem_params["vgoal"]
    thinit = problem_params["thinit"]
    thgoal = problem_params["thgoal"]
   

    for bestsolution in X:
        points = []
        for i in range(0,len(bestsolution)-2,2):
            points.append([bestsolution[i], bestsolution[i+1]])
        
        
        weigths = []
        weigths.append(1.0)        
        weigths.append(1.0)
        weigths.append(bestsolution[-2])
        weigths.append(bestsolution[-1])  
        weigths.append(1.0)  
        # weigths.append((1.0+bestsolution[-2])/2)
        weigths.append(1.0)
        
        # t = np.arange(0,1,0.01)
        _, fx, fy = nurbs(pti=pinit, ptf=pgoal, thi=thinit, thf=thgoal, points=points, weigths=weigths, delta=0.01)
        
        if legend =="":
            ax.plot(fx, fy,linestyle=l,color=c,alpha=alphac)
        else:
            ax.plot(fx, fy,linestyle=l,color=c,label=legend)

        
        if robot_in_path==True:
            for fxi, fyi in zip(fx, fy): 
                circle2 = plt.Circle((fxi, fyi), r, color=None, facecolor=None, edgecolor='g',fill=False, ls='--', alpha=0.5)    
                ax.add_artist(circle2)

    
    
    return fx, fy

def drawCurves_spline(X, ax, problem_params, dt=0.01,  c='',l='-', angle=0, alphac=1.0,label="", legend="", robot_in_path=False):
    # img = plt.imread("./campo.jpg")
    # img = plt.imread("./cva-cvd.png")
    # ax.imshow(img, extent=[0, 1.5, 0, 1.3]) # coloca do tamanho da imagem prevista    

    r = problem_params["r"]
    obs = problem_params["obs"]
    pinit = problem_params["pinit"]
    pgoal = problem_params["pgoal"]
    vinit = problem_params["vinit"]
    vgoal = problem_params["vgoal"]
    thinit = problem_params["thinit"]
    thgoal = problem_params["thgoal"]

    for bestsolution in X:    
        
        
        p0 = np.array([pinit[0], pinit[1]])
        p0l = np.array([vinit[0], vinit[1]])
        p1 = p2 = np.array([bestsolution[0], bestsolution[1]])
        p1l = p2l = np.array([bestsolution[2], bestsolution[3]])
        p3 = np.array([pgoal[0], pgoal[1]])
        p3l = np.array([vgoal[0], vgoal[1]])

        fx, fy = spline(dt, p0, p1, p0l, p1l)
        fx2, fy2 = spline(dt, p2, p3, p2l, p3l)
        
        if robot_in_path==True:
            for fxi, fyi in zip(fx, fy): 
                circle2 = plt.Circle((fxi, fyi), r, color=None, facecolor=None, edgecolor='g',fill=False, ls='--', alpha=0.5)    
                ax.add_artist(circle2)
            for fxi, fyi in zip(fx2, fy2): 
                circle2 = plt.Circle((fxi, fyi), r, color=None, facecolor=None, edgecolor='g', fill=False, ls='--', alpha=0.5)    
                ax.add_artist(circle2)


        if c=='':
            ax.plot(fx, fy,'--g')
            ax.plot(fx2, fy2,'--r')
        else:
            if legend =="":
                ax.plot(fx, fy,linestyle=l,color=c, alpha=alphac)
                ax.plot(fx2, fy2,linestyle=l,color=c, alpha=alphac)
            else:
                ax.plot(fx, fy,linestyle=l,color=c,label=legend)
                ax.plot(fx2, fy2,linestyle=l,color=c)
    
    # # desenha obstáculos
    # for obi in obs: 
    #     circle1 = plt.Circle((obi[0], obi[1]), obi[2]/2, color=None, facecolor=None, edgecolor='r',ls='--')    
    #     ax.add_artist(circle1)

    #     # ret = plt.Rectangle((obi[0]-r,obi[1]-r),r*2,r*2, color="k")
    #     # ax.add_artist(ret)

    # # desenha bola
    # circle1 = plt.Circle((pgoal[0], pgoal[1]), 0.042/2, color='y')
    # ax.add_artist(circle1)
    # # desenha robo
    # if angle == 45:
    #     ret = plt.Rectangle((pinit[0] +r - 2*np.sin(angle)*r,pinit[1]+r -4*np.sin(angle)*r),r*2,r*2, edgecolor="k", facecolor='b', angle=angle)
    # else:
    #     ret = plt.Rectangle((pinit[0] -r ,pinit[1] -r),r*2,r*2, edgecolor="k", facecolor='b', angle=0.0)
    # ax.add_artist(ret) 

    # # desenha orientação inicial e final do robô
    # plt.quiver(pinit[0], pinit[1], np.cos(thinit*np.pi/180), np.sin(thinit*np.pi/180),color='m',scale=15)
    # plt.quiver(pgoal[0], pgoal[1], np.cos(thgoal*np.pi/180), np.sin(thgoal*np.pi/180),color='m',scale=15)



def drawVSSSoccerAll(problem_params, fitall_nurbs=[], path_all_nurbs=[], fitall_spline=[],  path_all_spline=[], path_all_vectorfield_x=[], path_all_vectorfield_y=[], save=0, save_extension='.png', img_path="", path_name = "", robot_in_path=False):
    """

    """ 
    cases = problem_params["cases"]   
    for i, _ in enumerate(cases):
        fig = plt.figure(figsize=(10,10)) 
        ax = fig.add_subplot(111) 

        r = problem_params["r"]
        obs = problem_params["obs"]
        pinit = problem_params["pinit"]
        pgoal = problem_params["pgoal"]
        vinit = problem_params["vinit"]
        vgoal = problem_params["vgoal"]
        thinit = problem_params["thinit"]
        thgoal = problem_params["thgoal"]
        
        # desenha obstáculos
        for obi in obs: 
            circle1 = plt.Circle((obi[0], obi[1]), obi[2], color=None, facecolor=None, edgecolor='r',ls='--')    
            ax.add_artist(circle1)
            
            ret = plt.Rectangle((obi[0]-obi[2]/np.sqrt(2),obi[1]-obi[2]/np.sqrt(2)),obi[2]/np.sqrt(2)*2,obi[2]/np.sqrt(2)*2, color="k", angle=0)
            ax.add_artist(ret)

        # desenha bola
        circle1 = plt.Circle((pgoal[0], pgoal[1]), 0.042/2, color='y')
        ax.add_artist(circle1)

        # desenha orientação inicial e final do robô
        ax.quiver(pinit[0], pinit[1], np.cos(thinit*np.pi/180), np.sin(thinit*np.pi/180),color='m',scale=15)
        ax.quiver(pgoal[0], pgoal[1], np.cos(thgoal*np.pi/180), np.sin(thgoal*np.pi/180),color='m',scale=15)

        # desenha robo            
        size_robot = r/np.sqrt(2)*2
        
        anchor = np.array([pinit[0],pinit[1] ])
        

        circle1 = plt.Circle((pinit[0], pinit[1]), r, color=None, facecolor=None, edgecolor='r',ls='--')   
        ax.add_artist(circle1)
        th = -thinit
        anchor =  anchor - np.array([[size_robot/2,size_robot/2]]).dot(np.array([[np.cos(th*np.pi/180), -np.sin(th*np.pi/180)],[np.sin(th*np.pi/180), np.cos(th*np.pi/180)]]))
        anchor = anchor[0]
        th =  thinit
        
        ret = plt.Rectangle((anchor[0], anchor[1]),size_robot,size_robot, edgecolor="k", facecolor='b', angle=th)
        
        ax.add_artist(ret) 

        

        if not img_path in "":
            img = plt.imread(img_path)
            ax.imshow(img, extent=[0, 1.5, 0, 1.3]) # coloca do tamanho da imagem prevista
            ax.axis([0, 1.5, 0.0, 1.3])
        if np.any(fitall_nurbs):
            idbest = np.argmin(fitall_nurbs[i])
            idworse = np.argmax(fitall_nurbs[i])
            bestsolution = path_all_nurbs[i][idbest]
            worsesolution = path_all_nurbs[i][idworse]
            drawCurves([bestsolution], ax, problem_params, l='-.', c='r', legend="DE-NURBS", robot_in_path=robot_in_path)
            # drawCurves([worsesolution], ax, l=':', c='r', angle=angleR, legend="DE-nurbs (worse)")
            drawCurves(path_all_nurbs[i], ax, problem_params, l='-',c='r', alphac=0.2, robot_in_path=False)

        if np.any(fitall_spline):
            idbest_spline = np.argmin(fitall_spline[i])
            idworse_spline = np.argmin(fitall_spline[i])
            bestsolution_spline = path_all_spline[i][idbest_spline]
            worsesolution_spline = path_all_spline[i][idworse_spline]
            # ax.set_title("Case #"+ str(situations[i]))
            drawCurves_spline([bestsolution_spline], ax, problem_params, l='--', c='b',  legend="DE-Spline", robot_in_path=robot_in_path)
            # drawCurves_spline([worsesolution_spline], ax, l=':', c='b', angle=angleR, legend="DE-spline (worse)")
            drawCurves_spline(path_all_spline[i], ax, problem_params, l='-' , c='b',  alphac=0.1, robot_in_path=False)

        if np.any(path_all_vectorfield_x):
            lines = plt.plot(path_all_vectorfield_x[i] , path_all_vectorfield_y[i],'-g',label="Vector Field planner")
        
        plt.legend(framealpha=1, frameon=True, fontsize="x-large")
        
        if save:
            namefig = path_name + str(cases[i])
            print(namefig)
            fig.savefig(namefig+save_extension, bbox_inches = 'tight', pad_inches = 0)
        plt.show()