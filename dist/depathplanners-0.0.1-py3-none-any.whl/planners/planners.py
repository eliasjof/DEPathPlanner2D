import pyade.lshade
from numba import jit
import numpy as np
import time

from geomdl import NURBS
from geomdl import knotvector

#import inspect

import warnings 
warnings.filterwarnings('ignore')


class depahplanner:

    def __init__(self, type = "DE-SPLINE", debug=0 ):
        '''
        type = DE-NURBS or DE-SPLINE        
        use set_problem and set_algorithm to customize
        '''       
        

        self.algorithm = pyade.lshade
        self.type = type        


        # default problem params
        self.set_problem()

        # default algorithm params
        self.set_algorithm()

        # log variables
        self.log_fit = []
        self.log_time = []
        self.log_path = [] 
        self.debug = debug

        # run 4x (pyade.lshade error when dont do this)
        self.max_iterations=3
        self.run(repeat_test=1)
        
        # log variables
        self.log_fit = []
        self.log_time = []
        self.log_path = [] 
        
        

    def set_problem(self, problem_params=None):
        if problem_params is None:            
            problem_params = {
            "r": 0.075/2*np.sqrt(2),            
            "pinit":[0.2, 0.2],
            "pgoal":[0.6, 0.6], 
            "vinit":[.0, .0], 
            "vgoal":[0., 0.0],
            "thinit":0, 
            "thgoal":0, 
            "obs" : [],             
            "dt" : 0.01, 
            "npoints": 20, 
            "cases" : [0]
            }
        self.r = problem_params["r"]
        self.obs = problem_params["obs"]
        self.pinit = problem_params["pinit"]
        self.pgoal = problem_params["pgoal"]
        self.vinit = problem_params["vinit"]
        self.vgoal = problem_params["vgoal"]
        self.thinit = problem_params["thinit"]
        self.thgoal = problem_params["thgoal"]
        self.npoints = problem_params["npoints"]

        self.dt = np.linalg.norm(np.array(self.pinit)-np.array(self.pgoal))/self.npoints
        
        problem_params["dt"] =  self.dt
        self.problem_params = problem_params

    def get_problem_params(self):
        return self.problem_params
    
    def get_algorithm_params(self):
        return self.algorithm_params
    
    def set_algorithm(self,algorithm_params=None):
        if algorithm_params is None:            
            algorithm_params = {
                "boundaries" : [],
                "population_size" : 30,
                "memory_size" : 3, 
                "max_iterations" : 1000, 
                "alpha_costfunction" : 0.00125,
                "external_costfunction": None              
            }
         
        self.memory_size = algorithm_params["memory_size"]
        self.max_iterations = algorithm_params["max_iterations"]
        self.population_size = algorithm_params["population_size"]
        self.alpha = algorithm_params["alpha_costfunction"]
        if algorithm_params["external_costfunction"] is not None: 
            self.costfunction = algorithm_params["external_costfunction"]
        elif self.type in "DE-NURBS":
            self.costfunction = self.costfunction_nurbs
        else:
            self.costfunction = self.costfunction_spline
        
        if not np.any(algorithm_params["boundaries"]):
            # default for VSSSoccer
            if self.type in "DE-NURBS": 
                algorithm_params["boundaries"] = np.array([[-5.,5.],[-5.,5.],[-5.,5.],[-5.,5.],[0.01,1.],[0.01,1.]]) 
            else:
                algorithm_params["boundaries"] = np.array([[.0, 1.5- 0.075/2],[.0, 1.3- 0.075/2],[-2.0, 2.0],[-2.0, 2.0]])
        self.boundaries = algorithm_params["boundaries"]

        self.algorithm_params = algorithm_params

    def print_params(self) :
        # signature = inspect.signature(self.__init__)
        # for name, parameter in signature.parameters.items():
        #     print(name, parameter.default, parameter.annotation, parameter.kind)
        print(self.type)
        print(self.algorithm_params)
        print(self.problem_params)
       
    def run(self, repeat_test=1):
        
        self.log_fit  = []
        self.log_time = []
        self.log_path = []
        
        for i in range(repeat_test):
            
            if self.type in "DE-NURBS":                
                params = self.algorithm.get_default_params(dim=6)                 
                # We define the boundaries of the variables                
                params['bounds'] = self.boundaries                
                
            elif self.type in "DE-SPLINE":
                # We get default parameters for a problem with two variables
                params = self.algorithm.get_default_params(dim=4)                 
                # We define the boundaries of the variables
                params['bounds'] = self.boundaries
                
                
            params['func'] = self.costfunction
            params['population_size'] = self.population_size
            params['memory_size'] = self.memory_size
            params['max_evals'] = self.max_iterations

            
            # We indicate the function we want to minimize
            
            params['opts'] = None

            start = time.time()
            # We run the algorithm and obtain the results
            # solution, fitness = algorithm.apply(timeT=2,**params)
            solution, fit_value = self.algorithm.apply(**params)
            now = time.time()
            time_elapse = now - start 

            best_solution = solution             
            #self.printlog(str(i)  + " - Solution = " + str(best_solution) + str(fit_value))    
            
            self.log_path.append(best_solution)
            self.log_fit.append(fit_value)
            self.log_time.append(time_elapse)
         
            
    def printlog(self, msg):
        if self.debug:
            print(msg)    

        

    def set_obstacles(self, obs):
        self.obs = obs    
    
    #@jit(forceobj=True)
    def nurbs(self, pti, ptf, thi, thf, points, weigths = [1.0,1.0,1.0,1.0,1.0], alpha1=0.4, alpha2=0.4, angle_format='d'):
        
        if angle_format=='d':
            thi = thi*np.pi/180.0
            thf = thf*np.pi/180.0
        
        # start = time.time()
        curve = NURBS.Curve()
        # Set degree
        curve.degree = 5
        
        # para determinar o segundo e o penultimo ponto de controle a partir do angulo desejado
        distT = np.linalg.norm(np.array(ptf) - np.array(pti))
        vi = alpha1*distT #porcentagem do comprimento total da distância entre os dois pontos
        vf = alpha2*distT
        pti2 = [np.cos(thi)*vi + pti[0], np.sin(thi)*vi + pti[1]]
        ptf2 = [-np.cos(thf)*vf + ptf[0], - np.sin(thf)*vf + ptf[1]]

        # Set control points
        ctrlpts = []
        ctrlpts.append(pti)
        ctrlpts.append(pti2)
        for pt in points:
            ctrlpts.append(pt)
        ctrlpts.append(ptf2)
        ctrlpts.append(ptf)
        curve.ctrlpts = ctrlpts
       
        curve.knotvector = knotvector.generate(curve.degree, len(ctrlpts))
        # Set evaluation delta
        curve.delta = self.dt/1.5 # default delta=0.05

        curve.weights = weigths
        # Evaluate curve
        curve.evaluate()        

        f = np.array(curve.evalpts)
        fx = [fi[0] for fi in f]
        fy = [fi[1] for fi in f]
        # now = time.time()
        # tempo_gasto = now - start 
        # print("t = ", tempo_gasto)
        return fx, fy
    
    # @jit(forceobj=True)
    # def isfree(self, fx, fy, obs=None): 
    
    #     if obs==None: obs = self.obs
    #     if max(fx) > 1.5 -self.r  or min(fx) < 0.0 + self.r  or max(fy) > 1.3 -self.r  or min(fy) < 0.0 +self.r :
    #         return 10e6

    #     test = [(np.array(fx)-o[0])**2 + (np.array(fy)-o[1])**2 - (o[2]/np.sqrt(2)+self.r)**2 for o in obs] 
    #     test = np.array(test)
    #     value = len(test[test <= 0 ])*10e6
                
    #     return value
        

    def spline(self, p0, p1, p0l, p1l):
        """ retorna um conjunto de pontos que compõem um spline, componente x: fx e componente y: fy
        """  
        t = np.linspace(0,1,int(self.npoints/2))#np.arange(0,1,self.dt)  
        f1 = 2*t**3 -3*t**2 + 1
        f2 = -2*t**3 + 3*t**2
        f3 = t**3 -2*t**2 + t
        f4 = t**3 - t**2    

        fx = p0[0]*f1 + p1[0]*f2 + p0l[0]*f3 + p1l[0]*f4
        fy = p0[1]*f1 + p1[1]*f2 + p0l[1]*f3 + p1l[1]*f4

        return fx, fy

    
    @jit(forceobj=True)
    def costfunction_nurbs(self, parameters):
        """ retorna a função de custo, combinação entre suavidade e comprimento
        parameters deve conter uma lista com 6 elementos"""   
        points = []        
        for i in range(0,len(parameters)-2,2):
            points.append([parameters[i], parameters[i+1]])

        weigths = []
        weigths.append(1.0)
        weigths.append(1.0)          
        weigths.append(parameters[-2])
        weigths.append(parameters[-1])    
        weigths.append(1.0)        
        weigths.append(1.0)
        
        fx, fy = self.nurbs(pti=self.pinit, ptf=self.pgoal, thi=self.thinit, thf=self.thgoal, points=points, weigths=weigths, alpha1=0.4, alpha2=0.4)
       
        # penalidade =  self.isfree(fx, fy)
        penalidade  = 0
        if max(fx) > 1.5 -self.r  or min(fx) < 0.0 + self.r  or max(fy) > 1.3 -self.r  or min(fy) < 0.0 +self.r :
            penalidade += 10e6

        test = [(np.array(fx)-o[0])**2 + (np.array(fy)-o[1])**2 - ((o[2]+self.r))**2 for o in self.obs] 
        test = np.array(test)
        penalidade += len(test[test <= 0 ])*10e6
        
        
        ai = np.linalg.norm(np.diff(np.array([fx[:-1],fy[:-1]])).T, axis=1)
        bi = np.linalg.norm(np.diff(np.array([fx[1:],fy[1:]])).T, axis=1) #np.diff(np.array([fx,fy])).T #np.linalg.norm(pt1-pt)
        pt = np.array([fx[2:],fy[2:]])
        pt2 = np.array([fx[:-2],fy[:-2]])  
        ci = np.linalg.norm((pt2-pt).T, axis=1)

        th = (ai**2 + bi**2 - ci**2)/(2*ai*bi)
        th = np.clip(th, a_min=-1.0, a_max=1.0)
        v = np.diff(np.array([fx,fy]))       
        #print(v.shape, np.linalg.norm(v, axis=0).shape, len((2*(np.pi - np.arccos(th))/(ai + bi))**2))
        smoothness = np.sum(np.linalg.norm(v[:,1:], axis=0)*(2*(np.pi - np.arccos(th))/(ai + bi))**2)
        #smoothness = self.dt*np.sum((2*(np.pi - np.arccos(th))/(ai + bi))**2) 
        if np.isnan(smoothness):
            smoothness = 10e6
        length =  np.sum(np.linalg.norm(np.diff(np.array([fx,fy])).T, axis=1))

        f2 = smoothness
        f1 = length        

        return self.alpha*f2 + f1 + penalidade 

    
    @jit(forceobj=True)
    def costfunction_spline(self, parameters):
        """ retorna a função de custo, combinação entre suavidade e comprimento
        parameters deve conter uma lista com 4 elementos"""        

        # define os pontos
        p0 = np.array([self.pinit[0], self.pinit[1]])
        p0l = np.array([self.vinit[0], self.vinit[1]])
        p1 = p2 = np.array([parameters[0], parameters[1]])
        p1l = p2l = np.array([parameters[2], parameters[3]])
        p3 = np.array([self.pgoal[0], self.pgoal[1]])
        p3l = np.array([self.vgoal[0], self.vgoal[1]])

        #a = time.time()
        # obtem dois splines
        fx1, fy1 = self.spline(p0, p1, p0l, p1l)
        fx2, fy2 = self.spline(p2, p3, p2l, p3l)
        #print("curve = ", time.time() - a) 

        # une os splines
        fcx = np.append(fx1,fx2[1:])
        fcy = np.append(fy1,fy2[1:])

        fx = fcx
        fy = fcy

        # verifica se o caminho está livre de obstáculos
        #a = time.time()
        #penalidade = self.isfree(fcx, fcy)
        penalidade  = 0
        if max(fx) > 1.5 -self.r  or min(fx) < 0.0 + self.r  or max(fy) > 1.3 -self.r  or min(fy) < 0.0 +self.r :
            penalidade += 10e6

        test = [(np.array(fx)-o[0])**2 + (np.array(fy)-o[1])**2 - ((o[2]+self.r))**2 for o in self.obs] 
        test = np.array(test)
        penalidade += len(test[test <= 0 ])*10e6

        # obtém a suavidade s do caminho e o comprimento total l do caminho
        # s, l = self.smoothness(fcx, fcy)
        #a = time.time()
        
        smoothness = 0
        
        ai = np.linalg.norm(np.diff(np.array([fx[:-1],fy[:-1]])).T, axis=1)
        bi = np.linalg.norm(np.diff(np.array([fx[1:],fy[1:]])).T, axis=1) #np.diff(np.array([fx,fy])).T #np.linalg.norm(pt1-pt)
        pt = np.array([fx[2:],fy[2:]])
        pt2 = np.array([fx[:-2],fy[:-2]])  
        ci = np.linalg.norm((pt2-pt).T, axis=1)

        th = (ai**2 + bi**2 - ci**2)/(2*ai*bi)
        th = np.clip(th, a_min=-1.0, a_max=1.0)
        v = np.diff(np.array([fx,fy]))      
        #print(v.shape, np.linalg.norm(v, axis=0).shape, len((2*(np.pi - np.arccos(th))/(ai + bi))**2))
        smoothness = np.sum(np.linalg.norm(v[:,1:], axis=0)*(2*(np.pi - np.arccos(th))/(ai + bi))**2)         
        #smoothness = self.dt*np.sum((2*(np.pi - np.arccos(th))/(ai + bi))**2) 

        if np.isnan(smoothness):
            smoothness = 10e6
        length =  np.sum(np.linalg.norm(np.diff(np.array([fx,fy])).T, axis=1))
        # length =  np.sum(np.linalg.norm(np.diff(np.array([fx1,fy1])).T, axis=1)) + np.sum(np.linalg.norm(np.diff(np.array([fx2,fy2])).T, axis=1))

        f2 = smoothness
        f1 = length        

        return self.alpha*f2 + f1 + penalidade



    def get_curve_points(self, path_params, problem_params):
        """
        input: path_params, problem_params
        return: fx, fy (curve points x, y)
        """
        
        pinit = problem_params["pinit"]
        pgoal = problem_params["pgoal"]
        vinit = problem_params["vinit"]
        vgoal = problem_params["vgoal"]
        thinit = problem_params["thinit"]
        thgoal = problem_params["thgoal"]
        npoints = problem_params["npoints"]

        dt = np.linalg.norm(np.array(pinit)-np.array(pgoal))/npoints
        
        
        problem_params["dt"] =  dt
        if self.type in "DE-NURBS":
            # Define the points of the curve
            points = []        
            for i in range(0,len(path_params)-2,2):
                points.append([path_params[i], path_params[i+1]])

            weigths = []
            weigths.append(1.0)
            weigths.append(1.0)          
            weigths.append(path_params[-2])
            weigths.append(path_params[-1])    
            weigths.append(1.0)        
            weigths.append(1.0)

            fx, fy = self.nurbs(pti=pinit, ptf=pgoal, thi=thinit, thf=thgoal, points=points, weigths=weigths, alpha1=0.4, alpha2=0.4)
        else:
            # Define the points of the curve            
            p0 = np.array([pinit[0], pinit[1]])
            p0l = np.array([vinit[0], vinit[1]])
            p1 = p2 = np.array([path_params[0], path_params[1]])
            p1l = p2l = np.array([path_params[2], path_params[3]])
            p3 = np.array([pgoal[0], pgoal[1]])
            p3l = np.array([vgoal[0], vgoal[1]])
            fx1, fy1 = self.spline(p0, p1, p0l, p1l)
            fx2, fy2 = self.spline(p2, p3, p2l, p3l)

            # Join the splines
            fx = np.append(fx1,fx2[1:])
            fy = np.append(fy1,fy2[1:])      
        return fx, fy

     
def getPlanner(type="DE-SPLINE",  debug=0 ):
    '''
    problem_params = {
            "r": maximum width/length robot            
            "pinit": initial position, e.g. [0.2, 0.2], 
            "pgoal": goal position, e.g. [0.8, 0.65], 
            "vinit": initial velocity direction [0.6, 0.45], 
            "vgoal": goal velocity direction [0.6, 0.45],
            "thinit": initial angle, 
            "thgoal": goal angle, 
            "obs" : list of obstacles position, 
            "dt" : discretization parameter,
            "boundaries": e.g. for spline and VSSSoccer:  np.array([[.0, 1.5-r],[.0, 1.3-r],[-3.0, 3.0],[-3.0, 3.0]])   
            }
    type = DE-NURBS or DE-SPLINE    
    
    population_size = initial size of population L-SHADE
    max_iterations =  maximum iterations L-SHADE    

    '''
    
    planner = depahplanner(type, debug=debug )
    return planner

def costfunction(fx, fy, problem_params, alpha=0.01):
    r = problem_params["r"]
    obs = problem_params["obs"]    
    
    # penalidade =  self.isfree(fx, fy)
    penalidade  = 0
    if max(fx) > 1.5 -r  or min(fx) < 0.0 + r  or max(fy) > 1.3 -r  or min(fy) < 0.0 +r :
        penalidade += 10e6

    test = [(np.array(fx)-o[0])**2 + (np.array(fy)-o[1])**2 - ((o[2]+r))**2 for o in obs] 
    test = np.array(test)
    penalidade += len(test[test <= 0 ])*10e6
    
    
    ai = np.linalg.norm(np.diff(np.array([fx[:-1],fy[:-1]])).T, axis=1)
    bi = np.linalg.norm(np.diff(np.array([fx[1:],fy[1:]])).T, axis=1) #np.diff(np.array([fx,fy])).T #np.linalg.norm(pt1-pt)
    pt = np.array([fx[2:],fy[2:]])
    pt2 = np.array([fx[:-2],fy[:-2]])  
    ci = np.linalg.norm((pt2-pt).T, axis=1)

    th = (ai**2 + bi**2 - ci**2)/(2*ai*bi)
    th = np.clip(th, a_min=-1.0, a_max=1.0)
    v = np.diff(np.array([fx,fy]))       
    #print(v.shape, np.linalg.norm(v, axis=0).shape, len((2*(np.pi - np.arccos(th))/(ai + bi))**2))
    smoothness = np.sum(np.linalg.norm(v[:,1:], axis=0)*(2*(np.pi - np.arccos(th))/(ai + bi))**2)
    #smoothness = self.dt*np.sum((2*(np.pi - np.arccos(th))/(ai + bi))**2) 
    if np.isnan(smoothness):
        smoothness = 10e6
    length =  np.sum(np.linalg.norm(np.diff(np.array([fx,fy])).T, axis=1))

    f2 = smoothness
    f1 = length        

    return alpha*f2 + f1 + penalidade